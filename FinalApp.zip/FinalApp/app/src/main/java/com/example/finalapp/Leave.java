package com.example.finalapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Random;

public class Leave extends AppCompatActivity {
    EditText toDate, fromDate, subject, content;
    Button submitbtn;
    FirebaseAuth mAuth;
    FirebaseFirestore firestore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave);
        toDate = findViewById(R.id.toDate);
        fromDate = findViewById(R.id.fromDate);
        subject = findViewById(R.id.subject);
        mAuth = FirebaseAuth.getInstance();
        content = findViewById(R.id.content);
        submitbtn = findViewById(R.id.submitbtn);
        firestore = FirebaseFirestore.getInstance();
        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dateTo, dateFrom, letter_sub, letter_content, userID;
                dateTo = toDate.getText().toString();
                dateFrom = fromDate.getText().toString();
                letter_sub = subject.getText().toString();
                letter_content = content.getText().toString();
                HashMap<String, Object> mMap = new HashMap<>();
                userID = mAuth.getCurrentUser().getEmail();
                DocumentReference documentReference = firestore.collection("Applications").document(userID);
                mMap.put("Content: ", letter_content);
                mMap.put("Subject: ", letter_sub);
                mMap.put("To: ", dateTo);
                mMap.put("From:", dateFrom);
                documentReference.set(mMap).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(Leave.this, "Sent", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}