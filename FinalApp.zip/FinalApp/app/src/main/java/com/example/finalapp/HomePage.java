package com.example.finalapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class HomePage extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
    }
    public void openAttendance(View view){ startActivity(new Intent(this, Attendance.class));}
    public void openClassmates(View view){ startActivity(new Intent(this, Classmates.class));}
    public void openGallery(View view){ startActivity(new Intent(this, Gallery.class));}
    public void openInfo(View view){
        startActivity(new Intent(this, InfoPage.class));
    }
    public void openLeave(View view){
        startActivity(new Intent(this, Leave.class));
    }
    public void openTimeTable(View view) {startActivity(new Intent(this, TimeTable.class));}
    public void openResources(View view){ startActivity(new Intent(this, Resources.class));}
    public void openFeeStructure(View view){ startActivity(new Intent(this, FeeStructure.class));}
}