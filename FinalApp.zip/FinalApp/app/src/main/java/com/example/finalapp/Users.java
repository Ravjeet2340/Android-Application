package com.example.finalapp;

public class Users {
    String name, course;

    public String getName() {
        return name;
    }

    public String getCourse() {
        return course;
    }

    public Users(String name, String course) {
        this.name = name;
        this.course = course;
    }

    public Users() {
    }
}
