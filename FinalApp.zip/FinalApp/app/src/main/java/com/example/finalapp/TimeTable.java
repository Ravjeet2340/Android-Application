package com.example.finalapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TimeTable extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_table);
    }
}
